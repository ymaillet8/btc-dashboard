# BTC Bottom Watch — Free Automated Dashboard (v9)

Updates itself once a day, for genuinely free, at a shareable public URL.
**20 on-chain/technical indicators + a live 5-horizon Polymarket prediction
board**, added following your uploaded forecaster-track-record research.

## What's new in v9

**1. Prediction Market section — Polymarket, 5 horizons, fully automated.**
Uses the real Polymarket Gamma API (`gamma-api.polymarket.com`) — free,
keyless, and a completely separate service from BGeometrics, so this adds
**zero cost to the 10-request BGeometrics budget**. Important correction
worth knowing about: the script structure you were given (via Gemini)
queried `https://polymarket.com` — the website itself — with query
parameters, which does not return usable market data. The real base URL is
`https://gamma-api.polymarket.com`, confirmed against multiple independent
API guides before writing any code.

How it works: once a day, it fetches active/non-closed Bitcoin-related
markets sorted by volume, then for each of your 5 requested horizons
(weekly ~7d, bi-weekly ~14d, monthly ~30d, quarterly ~90d, yearly ~365d) it
finds whichever live BTC market's expiration date falls closest to that
target, within a tolerance window, above a $25,000 volume floor to filter
out illiquid noise. Polymarket doesn't offer fixed weekly/monthly BTC
contracts — the specific question text (a $-threshold, a range, etc.)
varies day to day, so the dashboard shows the real question rather than
forcing everything into one normalized number. If no genuinely close match
exists for a horizon, it says so honestly rather than picking a bad one.

**Deliberately not scored into the weighted verdict.** Your own uploaded
report is explicit that prediction markets reflect the crowd's *current*
probability, not a forward-looking forecast, and have shown real
overconfidence right at a threshold (a 91%-priced "$100k by November 2024"
market still resolved NO days later). This section is shown as its own
context, exactly as the report recommends — not folded into the tally.

Two known limitations, disclosed rather than papered over: (1) the exact
bucket matched can shift day to day as old markets close and new ones
open — that's expected behavior given how Polymarket actually works, not a
bug; (2) I couldn't test this against Polymarket's live API from my own
environment either (network-restricted), so it's verified against a
realistic mock built from confirmed real response shapes, not a live call —
watch the first real run's output for anything unexpected.

**2. NRPL (Net Realized P&L, BTC) added — VDD removed.** Your uploaded
report specifically recommends "capitulation/realized-loss magnitude" as a
bottom-confirmation signal (citing 2022's ~1.2M BTC in realized losses vs.
mid-2026's ~187k). NRPL is the closest confirmed-available proxy — and
genuinely confirmed, not a guess: the slug `nrpl-btc` was visible directly
in your own BGeometrics account's API usage examples early in this whole
project, unlike VDD's slug, which was always an inferred guess. Swapping
them costs nothing (VDD was context-only and never contributed to the
verdict score anyway) and moves you onto more solid ground. Still
context-only for now — no widely-cited fixed "buy" threshold exists for
NRPL specifically, so it's displayed, not scored, same honest treatment
Thermocap and Pi Cycle already get.

**Supply-quantile cost basis** (also mentioned in your report) was checked
against BGeometrics' full catalog and not found — noting this so you know
it was looked for, not overlooked.

## What's new in v8 — aSOPR, modeled rather than substituted

aSOPR's true definition requires per-UTXO lifespan data (excluding coin
movements under 1 hour old) that no free source exposes — confirmed via
Glassnode's own documentation. Rather than leave it manual or just show
plain SOPR as a vague stand-in, this models an estimate from a real
published mechanism:

Glassnode states that sub-1-hour UTXOs make up 20-40% of daily volume,
trade at ~breakeven (ratio ≈ 1.0), and dilute SOPR toward 1 — which is
exactly why aSOPR reads as "more responsive, and generally of greater
magnitude than the equivalent SOPR." That's a solvable relationship:

```
SOPR ≈ (dilution_share × 1.0) + (1 − dilution_share) × aSOPR
=> aSOPR ≈ (SOPR − dilution_share) / (1 − dilution_share)
```

Using the midpoint of Glassnode's stated range (30%) as `ASOPR_DILUTION_SHARE`
(adjustable near the top of `update_dashboard.py`). Verified before shipping:
breakeven maps to breakeven, and deviations from 1.0 get consistently
amplified (~1.43x) in the correct direction — matching the documented
behavior precisely, not just directionally.

**Labeled clearly on the dashboard as a modeled estimate, not a licensed
feed.** This uses the 10th and final BGeometrics request slot — **0 spare
now**, a deliberate tradeoff (a real indicator was judged more valuable
than retry headroom during a phase that's mostly done being actively
tested — see chat for the reasoning).

**Last genuine gap:** Whale accumulation/exchange netflow. Everything else
either has a real feed or a disclosed, mechanism-grounded estimate.

## What's new in v7 — correcting a v6 mistake

v6 concluded Pi Cycle, VDD, aSOPR, and Supply in Loss/Profit were entirely
absent from BGeometrics. That conclusion was wrong — it was based on a
partial dropdown list that hadn't been scrolled far enough to reach their
CDD/Price categories. Checking BGeometrics' **full site navigation**
(charts.bgeometrics.com/bitcoin_api.html) confirmed real chart pages exist
for three of the four:

1. **Pi Cycle** (`pi_cycle.html`), **VDD Multiplier** (`vdd.html`), and
   **Supply in Profit/Loss** (`supply_in_profit.html`) are genuinely
   available — added back with API slugs inferred from these confirmed
   chart filenames (`pi-cycle`, `vdd`, `supply-in-profit`), following the
   same naming pattern already confirmed correct for 6 other metrics. Not
   independently verified against live API docs (still can't access those
   directly) — same graceful "CHECK" fallback as always if a slug is off.
2. **aSOPR genuinely does not exist anywhere in their catalog** — this one
   really is gone, checked against their complete metric list.
3. **% Supply in Loss is derived, not fetched directly** — BGeometrics
   only exposes "Supply in Profit" under this slug; loss = 100 − profit,
   computed in the script.
4. Swapped out HODL Waves and generic SOPR (added in v6 as substitutes,
   lower priority on your ranking) to make room — this also **completes
   your original "top 8, no exceptions" mandate for the first time**,
   since Pi Cycle was always meant to be part of it.

**Now at 9 of 10 confirmed hourly requests — 1 spare**, down from v6's 2,
but still enough margin for one manual re-run within the hour if needed.

## What's new in v6 (still applies)

1. **Fixed a real parsing bug.** BGeometrics' actual API returns each
   metric as `[{"d": "2026-08-01", "unixTs": ..., "mvrvZscore": 0.3471}]`
   — a list containing one dict, with the real value under a camelCase key
   that varies per metric. The old parser didn't handle this shape and was
   returning the whole raw dict instead of the number inside it, which is
   why several rows showed "CHECK" even though the underlying API calls
   were succeeding. Fixed to generically extract whichever key isn't
   metadata (`d`, `unixTs`, etc.), so it works regardless of the exact
   field name for any given metric.

## What's new in v5 (still applies)

- **MACD (weekly, 12/26/9), Weekly RSI (14-period), Bollinger %B (20-week,
  2σ)** — all computed from the same CoinGecko price history already being
  fetched for Mayer Multiple and NVT Golden Cross. No new API calls, no new
  rate-limit exposure.
- **The full ranked list now includes these three**, inserted at #16, #19,
  and #21 respectively (see the standalone ranking artifact from earlier,
  or the WEIGHT_MAP in `update_dashboard.py`). They rank below the on-chain
  tier because they're generic technicals — the same math works on any
  asset, not just Bitcoin, and RSI/Bollinger in particular can stay pinned
  in "oversold" territory for months during a strong downtrend.
- **Two rows that were static before now have real computed signals:**
  Price vs. Realized Price (buy-favorable when spot trades below the
  realized-price cost basis) and Fear & Greed (buy-favorable at ≤20,
  "Extreme Fear"). Both used to just display "context only."
- **A weighted verdict section at the very bottom of the dashboard**,
  synthesizing every indicator's current state into one read.

## How the verdict synthesis works — and what it deliberately is not

Every indicator with a real (non-"CHECK") reading this run gets weighted
by its rank on your own ranked list (MVRV Z-Score, Realized Price, Puell,
Reserve Risk = weight 3; the on-chain tier below them = weight 2; Miner
Capitulation and MACD = weight 1.5; sentiment/blunt technicals = weight 1).
The script tallies what fraction of that weighted total is currently
buy-favorable and buckets the result into one of four narrative ranges
(minimal / partial / strong / near-maximal confluence), each with a short,
historically-grounded description of what that confluence level has
preceded in prior cycles.

**What this is:** a mechanical, fully transparent re-reading of the exact
rows already on the dashboard — nothing it says comes from outside the
data you can already see above it.

**What this is NOT:** financial advice, a price prediction, or a
substitute for your Power Law check. The script has no way to know your
Power Law status — it can only read the automated rows. The verdict text
says this explicitly every time it renders, and the master banner at the
top of the page still carries the actual veto.

If you want to change how much weight any indicator carries in this tally,
edit `WEIGHT_MAP` near the bottom of `update_dashboard.py` — it's a plain
dictionary, safe to adjust as your own conviction in specific indicators
shifts.

## What's automated now

**10 metrics via BGeometrics**, using all 10 of the confirmed 10/hour free
quota:
- MVRV Z-Score, Price vs. Realized Price, Puell Multiple, Reserve Risk,
  Thermocap Multiple, LTH-SOPR, Pi Cycle, VDD Multiplier — your full
  original top-8 ranked list, complete
- % Supply in Loss — derived (100 − Supply in Profit) from one call
- SOPR (raw) — fetched purely to derive the aSOPR estimate below, not
  shown as its own row

**Not from BGeometrics — computed separately, using zero extra quota:**
- Price vs. Production Cost — from live Blockchain.com hashrate/difficulty
  data plus two disclosed assumptions (see below)
- aSOPR (modeled estimate) — derived from the fetched SOPR value using a
  formula grounded in Glassnode's own documented mechanism (see v8 notes
  above), not a bare substitute

That's all 10 of 10 confirmed free hourly requests — **0 spare**, a
deliberate tradeoff, not an oversight (see below).

**9 more, self-computed from other free sources, using zero BGeometrics
quota:**
- Mayer Multiple, Drawdown Magnitude — from CoinGecko's free price history
- Miner Capitulation Index (Hash Ribbons proxy), NVT Golden Cross — from
  Blockchain.com's free hashrate/transaction-volume history
- MACD (weekly), Weekly RSI, Bollinger %B — from the same CoinGecko price
  history
- 1064/364-Day Cycle Rhythm — pure calendar math, no API at all
- Fear & Greed Index — Alternative.me

**Total: 20 automated indicators, synthesized into one weighted verdict at
the bottom of the page, updating daily with no action from you.**

## Zero spare requests — why, and what it costs you

Using all 10/10 hourly requests means a manual re-run within the same hour
will hit a 429. This was a deliberate choice, not an oversight: the
1-spare-request safety margin only has real value during active testing
(re-triggering the workflow repeatedly to check a fix) — once this runs
quietly on its daily schedule, the hourly cap never gets close to binding
regardless of whether 9 or 10 slots are used. A permanent indicator (aSOPR)
was judged more valuable than a margin that mostly protected against a
self-healing error (a failed row just shows "CHECK," nothing breaks). If
this becomes genuinely annoying during future tuning, drop one metric from
`BG_METRICS` near the top of `update_dashboard.py` — quick, reversible fix.

## Still manual — no free source, and no reasonable proxy either

**Whale accumulation/exchange netflow** — requires UTXO-flow/exchange-
labeled data that every free public source gates behind a paywall, and
unlike aSOPR, there's no documented mechanism simple enough to model a
reasonable estimate from data we do have.


Plus **Power Law**, which stays manual by design (see your TradingView-
alert plan).

## What you need (all free)
- A GitHub account
- A free BGeometrics API key (portal.bgeometrics.com/register)
- Nothing else — CoinGecko, Blockchain.com, and Alternative.me are all
  keyless, no signup required

## Setup steps

1. **Create a new public GitHub repository** (e.g. `btc-dashboard`).
2. **Upload:** `update_dashboard.py`, `dashboard_template.html`, and the
   `.github/workflows/update.yml` folder (keep that exact path).
3. **Get your BGeometrics key** at portal.bgeometrics.com/register.
4. **Add it as a secret:** repo Settings → Secrets and variables → Actions
   → New repository secret → name it `BGEOMETRICS_API_KEY` → paste the key.
5. **Enable GitHub Pages:** Settings → Pages → Source → GitHub Actions.
6. **Run it once manually:** Actions tab → "Update BTC Dashboard" →
   Run workflow. Check your live URL after ~30 seconds:
   `https://<your-github-username>.github.io/<repo-name>/dashboard.html`

Reruns automatically once a day from there.

## Two things worth understanding about the self-computed rows

*(Updated — these were refined against the actual published methodologies
after a deeper research pass, not the rough first-draft versions.)*

**Production Cost** is now grounded in a cited source rather than a picked
number: the $0.05/kWh electricity assumption is Cambridge University's own
CBECI model's stated global-average assumption (ccaf.io/cbnsi/cbeci/
methodology) — about as authoritative as a free source gets. The 20 J/TH
efficiency assumption sits in the middle of the range cited across current
sources (newest ASICs run ~15 J/TH, network-wide blended estimates
including older hardware run as high as 28 J/TH). Both are adjustable at
the top of `update_dashboard.py`. Important: this is an **electricity-only**
estimate, so it will read lower than "all-in" bank headlines like
JPMorgan's ~$78,000 (which also bake in hardware depreciation and
corporate overhead) — that's expected, not an inconsistency.

**Miner Capitulation Index** now implements Charles Edwards' full original
Hash Ribbons methodology (capriole.com/hash-ribbons-bitcoin-bottoms), not
just a simplified percentage: it tracks the 30-day/60-day hashrate
moving-average cross for capitulation/recovery, AND checks his recommended
price-momentum confirmation (10-day/20-day price moving average) before
calling it a genuine "BUY SIGNAL" rather than just "RECOVERING."

**NVT Golden Cross** now uses CryptoQuant's exact published formula
(userguide.cryptoquant.com/cryptoquant-metrics/network/nvt-golden-cross):
a z-score of the 10-day/30-day NVT moving-average spread against its own
300-day rolling volatility — not a raw percentage approximation. This
needed extending the CoinGecko and Blockchain.com history fetches from
~60-210 days to 340 days to have enough data for a proper 300-day
standard deviation window.

One number I checked and deliberately did NOT use: a widely-repeated
"infrastructure overhead multiplier" (~2.3x) from a secondary source that,
on closer inspection, didn't hold together mathematically — its own worked
example had an internal unit-conversion error. Rather than propagate that,
Production Cost here stays as a straightforward, verifiable calculation.


## If a BGeometrics slug turns out wrong

Actions tab → latest run → "Run update script" step → look for a line like
`! puell-multiple: HTTP 404`. That row will show "CHECK" on the dashboard
instead of breaking anything. Fix: log into portal.bgeometrics.com, find
the metric's real endpoint slug, update it in the `BG_METRICS` dictionary
near the top of `update_dashboard.py` — or paste the error to Claude.

## Updating the cycle-rhythm anchor dates

`CYCLE_ANCHORS` near the top of `update_dashboard.py` holds the last cycle
top's date and your model's projected offset to the next bottom. Update
these if your own cycle-timing model changes. Same for `ALL_TIME_HIGH_USD`
if a new ATH prints — used for the Drawdown Magnitude row.

## Sharing with your brother

Once Pages is live, send him the URL from step 6 — normal public webpage,
no login, always shows the latest daily-refreshed numbers.
